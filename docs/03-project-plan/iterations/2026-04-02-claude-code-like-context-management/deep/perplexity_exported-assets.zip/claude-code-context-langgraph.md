# Context Management in Claude Code and Design Patterns for LangGraph

## Executive overview

Claude Code treats "context" as a layered system spanning the model’s token window, a persisted session DAG, structured memory files, and on‑demand workspace tools, rather than as a single rolling chat buffer.[^1][^2][^3]
Context rot and window overflow are mitigated through aggressive compaction (auto and manual), progressive disclosure of skills and memory, subagents with independent windows, and careful filtering/deduplication of what actually gets sent to the API.[^3][^4][^5]
The leaked code and analyses confirm additional engineering patterns: a Git‑like JSONL DAG for conversations, multi‑layer memory with offline "autoDream" pruning, file‑read deduplication, and a `db8` filter that decides which message attachments are persisted to session history.[^6][^2][^4]
These patterns can be mapped cleanly onto a LangGraph design using explicit graph state (session DAG), policy‑driven context assembly, compaction nodes, skill/subagent subgraphs, and external memory stores.

## What "context" means in Claude Code

### Live model context vs durable state

Claude Code distinguishes between:

- **Live model context** – the tokens actually sent on each Claude API call: system prompt, tools definitions, skill metadata, CLAUDE.md, auto memory, current conversation strip, selected file contents, command outputs, and sometimes thinking blocks.[^7][^1][^3]
- **Durable state** – JSONL session logs, checkpoints, CLAUDE.md/\*.md instructions, MEMORY.md + topic files, skills, and project files, which are not all in the token window at once but can be pulled in on demand.[^5][^1][^3]

The runtime constantly assembles a *view* from durable state into live context according to token budgets and policies (auto compaction, skill loading, subagent boundaries).[^1][^3]

### Components of a typical context window

Debug views like `/context` and third‑party writeups show that a typical Claude Code context breakdown includes:[^8][^3]

- System prompt (hidden but includes tool schemas, permission model, output style, etc.).
- Built‑in tools descriptions (Bash, Read, Edit, Grep, Glob, Skill, subagent tools, MCP, etc.).[^4][^1]
- Skill metadata: names and short descriptions for available skills, subject to a character budget.[^5]
- CLAUDE.md + a slice of MEMORY.md (first 200 lines or 25 KB) plus imported `@` files.[^3][^1]
- Conversation strip: selected user/assistant messages and compaction summaries.
- Recent file reads and command outputs that the model still needs.
- Reserved *autocompact buffer* capacity so that compaction itself can run without hitting the hard limit.[^8]

Newer Claude models expose an explicit token budget tag and periodic `<system_warning>` updates like `Token usage: 35000/1000000; 965000 remaining`, so the model is context‑aware during long agentic loops.[^7]

## Session representation: JSONL DAG of messages

### JSONL layout and message schema

Session history is stored per project as JSONL under:

```text
~/.claude/projects/<project-slug>/<session-uuid>.jsonl
```

Each line is a self‑contained JSON object containing at least:

- `uuid`: unique message id.
- `parentUuid`: pointer to parent message in the same conversation, or `null` for a root.
- `type`: e.g. `"user"`, `"assistant"`, `"summary"`.
- `message`: inner object with the actual chat payload (`role`, `content`).
- Various metadata: `sessionId`, `cwd`, `gitBranch`, version, thinking metadata, etc.[^2]

The key property is that `parentUuid` turns the log into a **directed acyclic graph (DAG)** of messages, analogous to Git commits, where each conversation branch is defined by a *leaf* message (one whose `uuid` is never used as someone else’s `parentUuid`).[^2]

### Reconstructing conversations and summaries

When you run `claude --resume`, Claude Code:[^9][^2]

1. Reads *all* JSONL files for the project (not just a single session file).  
2. Parses each line into message objects.  
3. Builds a global DAG keyed by `uuid`/`parentUuid`.  
4. Finds all leaf messages and treats each as a distinct conversation tip.  
5. Resolves any `type: "summary"` entries attached via `leafUuid` to label conversations.[^2]

Because entries are atomic and idempotent, file order does not matter; lines could be shuffled and the reconstructed DAG (and conversations) would be identical.[^2]

Design implication: *history* is a persistent graph; the harness only needs to select a path and slice to project into the model’s token window.

## Automatic and manual compaction

### Auto compaction pipeline

Claude Code automatically compacts context when usage approaches a threshold (often surfaced via `/context` or UI indicators once 40–80% of the window is used).[^10][^11][^3]

The official docs describe the high‑level strategy:[^1][^3]

1. Track current context usage and remaining budget (including reserved space for compaction).  
2. When nearing the limit, **clear old tool outputs** first (logs, verbose command output, large file dumps).  
3. If still too full, **summarize earlier conversation** into a smaller number of synthetic messages preserving user requests, key decisions, and critical code snippets.  
4. Respect compaction instructions from CLAUDE.md and/or explicit `/compact` prompts to bias what is preserved.[^12][^3]

The API itself also supports **server‑side compaction** as a generic feature for long‑running conversations, which Claude Code takes advantage of.[^4][^7]

### Manual `/compact` command

The `/compact` command lets users trigger compaction with explicit instructions, overriding the default “preserve everything important” heuristic.[^13][^3]
The leaked `/compact` prompt, reproduced in community posts, shows that compaction is treated as a structured summarization task with explicit sections:[^12]

- Primary request and intent.  
- Key technical concepts.  
- Files and code sections (with rationale and important snippets).  
- Problems solved and ongoing troubleshooting.  
- Pending tasks.  
- Current work focus.  
- Optional next step.[^12]

When you run `/compact <focus>`, Claude Code passes a system/user prompt along those lines, plus your focus text (e.g. “focus on the API changes”), over the entire current strip of conversation and tool results; the response replaces many earlier messages with a denser summary block in the live context.[^3][^12]

### Partial compaction via rewind

`Esc` `Esc` or `/rewind` opens a rewind UI that can either restore older checkpoints or **“Summarize from here”**.[^3]
In the latter case, Claude Code selects a message as a checkpoint and only compacts *messages after that point*, leaving earlier history intact while shrinking the recent, noisy tail (e.g. long debugging branches).[^3]

From the DAG perspective, this is equivalent to inserting a `type:"summary"` node whose `parentUuid` is the checkpoint, then dropping some or all of the intervening nodes from the next API call’s context slice while still preserving them in the log.

### Leak‑derived details: multiple compaction modes

Reverse‑engineering summaries of the leaked code note that Claude Code implements **five distinct kinds of compaction**, including variants that target tool results, memory, and session history differently.[^4]
While the exact algorithms are not public, it is clear that compaction is not a single monolithic operation; the harness chooses among several compaction strategies depending on which part of state is consuming tokens (conversation vs. tool outputs vs. memory blocks).[^4]

## Skills and progressive disclosure

### Skill metadata vs full instructions

Claude Code uses *Skills* as structured prompt bundles with optional scripts and reference material.[^5][^1]
Each skill lives in `.claude/skills/<name>/SKILL.md` (plus optional supporting files), with YAML frontmatter controlling how and when it loads.[^5]

Context management behavior:[^5]

- **Level 1 (metadata):** Skill `name` and `description` are loaded at session start so the model can reason about which skills exist.  
- **Level 2 (instructions):** The body of `SKILL.md` is only loaded when the skill is actually invoked.  
- **Level 3+ (resources/scripts):** Referenced files are read on demand; scripts are executed via Bash and only their *output* enters context.

To curb bloat from many skills, there is an explicit **character budget** for descriptions: skill descriptions together are limited to ~1% of the context window, with a fallback of around 8000 characters, and individual descriptions are truncated to 250 characters in that listing.[^5]

### Controlling when skills enter context

Frontmatter flags give fine‑grained control over what shows up in the main window:[^5]

- `disable-model-invocation: true` – prevents the model from auto‑loading the skill; descriptions may be omitted from context unless invoked manually.  
- `user-invocable: false` – hides a skill from the `/` menu while still letting Claude invoke it when relevant.  
- `context: fork` – runs the skill in a **subagent** with its own fresh context window (described below).  
- `allowed-tools` – restricts which tools can be used while the skill is active.

This progressive disclosure is central to avoiding context rot from "giant CLAUDE.md" patterns: long‑lived, rarely used domain knowledge is packaged as skills so it does *not* occupy baseline context unless actually needed.[^14][^3][^5]

## Subagents and forked contexts

Subagents are configured in `.claude/agents/*.md` and can be bound to skills via `context: fork` and `agent: <name>`.[^3][^5]
A subagent runs with:

- Its own system prompt and tool set.  
- Its *own* conversation and context window, separate from the main session.  
- Summarized results returned to the main agent when done.[^1][^3]

This allows heavy operations (e.g. deep codebase exploration, large‑scale refactors, multi‑file QA) to consume another context window and report back via a compact summary, rather than pushing hundreds of file reads into the main thread.[^3]

Analyses of the leaked code also highlight that subagents are integrated with **prompt caching / KV cache reuse**, so a forked agent can reuse the shared prefix state without re‑spending tokens, effectively making parallelism “cheap” in token terms.[^4]

## Memory system and long‑term knowledge

### CLAUDE.md and MEMORY.md

Claude Code supports two main categories of persistent written memory:[^1][^3]

- **CLAUDE.md** – project‑ or user‑scoped instructions loaded every session; should be concise and contain only broadly applicable rules and workflows.  
- **MEMORY.md** – auto‑maintained file where Claude saves patterns, preferences, and observations; only the *first 200 lines or 25KB* are loaded each session to bound cost.[^1]

CLAUDE.md can in turn `@import` other markdown files (project README, architecture docs, further instructions), treating them as authoritative reference without necessarily pushing all content into context at once.[^3]

### Three‑layer memory and autoDream (leak‑derived)

The leaked sources, summarized by independent analyses, describe a **three‑layer memory architecture**:[^4]

1. `MEMORY.md` as an index / high‑level summary of durable knowledge.  
2. Per‑topic or per‑project memory files that are loaded on demand.  
3. Full session transcripts that can be searched when deeper recall is needed.[^4]

There is also an offline **"autoDream"** mode that periodically merges, deduplicates, and prunes memories, attempting to remove contradictions and stale information.[^4]
This separates *durable but rarely accessed* knowledge from the live window and keeps MEMORY.md itself small and high‑signal.

## Tool and repo context strategies

### Repo and git state as context inputs

Claude Code automatically surfaces the current working directory, git branch, and recent commits as part of its view of the repo.[^1][^4]
Leaked‑code analyses emphasize that it aggressively **puts repo state into context**, such as recent commits or branch info, when relevant to tasks like debugging a regression or reviewing a PR.[^4]

### File read deduplication and sampling

Reports based on the leaked source note explicit mechanisms for **file read deduplication** and **tool result sampling**:[^4]

- If the same file is read repeatedly, only minimal or deduped content is kept in live context; earlier redundant reads can be dropped.  
- Large tool outputs are trimmed or summarized to avoid blowing the window (e.g. truncating long logs and then asking the model to summarize them).[^4]

These patterns match the official recommendation to clear older tool outputs first during compaction, because they provide diminishing marginal value compared to user instructions and source code snippets.[^1][^3]

### External tools vs internal context

Claude Code strongly prefers using external CLIs (e.g. `gh` for GitHub, test runners, linters) and then inserting *only their output* into the prompt, rather than stuffing entire documentation or complex APIs into context.[^15][^3]
This keeps the live window focused on immediate results and decision points instead of raw reference data.

## Model‑side features: thinking tokens and context awareness

### Stripping extended thinking

Claude’s **extended thinking** (chain‑of‑thought) tokens count toward the context window but are *automatically stripped from history* for subsequent turns, except during a tool‑use cycle where the corresponding thinking block must be echoed back for validation.[^7]

That means the harness does not need to manually prune old thinking; the API will ignore previous `thinking` blocks when computing context for new user turns, which effectively gives more room for conversation and tool results.[^7]

### Context awareness and compaction

Newer models like Sonnet 4.6 are **context‑aware**: they receive an explicit token budget and periodic usage updates as part of the system messages.[^7]
This allows the model itself to reason about how verbose it can be and when it should suggest compaction (/compact) or clearing context.[^8][^7]

Claude Code combines this with harness‑side compaction: the CLI and IDE extensions surface context percentage and encourage users to stay below roughly 40–50% usage for best quality, even though hard limits are much higher.[^11][^10]

## Attachment and history filtering (db8)

A Reddit analysis of the leaked source mentions a function `db8` that decides what gets saved into session JSONL files.[^6]
According to that analysis:

- For non‑Anthropic users (`userType: "external"`), **all attachment‑type messages** are stripped before writing to disk.  
- Some of these attachments include `deferred_tools_delta` records that encode which tools have already been introduced to the model.  
- Stripping them can cause subtle bugs when resuming sessions because information about previously introduced tools is missing, forcing the harness to reintroduce tool schemas and potentially wasting context.[^6]

This illustrates a general design: there is an explicit *filtering layer* between live conversation and persisted history which decides what parts of a turn are important enough to store (and later replay into context) versus what remains ephemeral.

## User‑level context controls

From the docs and community posts, several user‑facing commands directly affect context:[^15][^1][^3]

- `/clear` – reset the live conversation context entirely (fresh window, same project).  
- `/context` – show detailed breakdown of system prompt, tools, skills, free space, and autocompact buffer.[^8]
- `/compact [focus]` – run compaction with optional focus instructions.[^13][^3]
- `/rewind` or `Esc Esc` – checkpoint/rewind or partial compaction from a selected message.[^3]
- `/btw` – ask ephemeral questions whose answers do *not* enter history, avoiding context growth.[^3]

IDE extensions add visual context indicators (e.g. status line or color‑coded percentage) and in some cases only show a warning when usage crosses a high threshold like 80%.[^10][^11]

## Mapping these patterns into a LangGraph design

The above behaviors can be decomposed into reusable design patterns for a LangGraph‑based system.

### 1. Represent sessions as a DAG in state

**Goal:** mirror Claude Code’s JSONL DAG so compaction and forking are graph operations, not ad‑hoc list slicing.

Suggested structure:

- Maintain a persistent `messages` table keyed by `uuid`, with fields like `parent_id`, `role`, `content`, `type` (`user`, `assistant`, `summary`, `tool_result`, etc.), and metadata (cwd, branch, tags).  
- On each turn, treat the active conversation as a **path from some root to a leaf** in this DAG; store the current leaf id in LangGraph state.  
- When forking, create a new leaf node that points to an earlier node as `parent_id`, similar to Git branching.[^2]

In LangGraph terms:

- Use a central **state store** (e.g. Redis, SQL, or file‑backed) to keep the DAG; graph nodes are stateless workers that operate on IDs.  
- A `BuildContextSlice` node walks ancestors from the current leaf backward, applies compaction rules, and outputs a linear list of messages to feed into the LLM.

### 2. Separate durable history from live context

Implement two layers:

- **History store:** full DAG of messages and tool results (like Claude’s JSONL).  
- **Context buffer:** the subset of messages and snippets actually passed to the LLM this turn.

Workflow in LangGraph:

1. User input arrives → create a `user` node in history (with parent = previous leaf).  
2. Run `ContextPlanner` node to decide which ancestors, summaries, and memory/skill artifacts to include, subject to a token budget.  
3. Pass this planned strip to the LLM node.  
4. When the LLM responds, write an `assistant` node to history and update current leaf.

Token budget estimation can use Anthropic’s token counting API or a local estimator, similar to how Claude Code and the API docs recommend planning around the context window.[^7][^3]

### 3. Implement compaction as explicit graph transformations

Create dedicated LangGraph nodes / subgraphs:

- `AutoCompactIfNeeded` – checks estimated token usage for the planned strip; if above threshold, calls a **compaction LLM** with a prompt similar to Claude Code’s `/compact` template and inserts a `summary` node into history pointing to a chosen checkpoint.[^12][^3]
- `ManualCompact` – triggered when user invokes a `/compact`-style command; same logic but with user‑supplied focus instructions and maybe a different policy for which messages to merge.  
- `PartialCompactFromCheckpoint` – compacts from a particular message id (for a rewind‑style "summarize from here"), replacing a run of nodes with a single `summary` node while keeping the originals for potential deep‑history search.[^3]

The planner should then prefer `summary` nodes over their children when building future context, unless the user explicitly drills into past details.

### 4. Progressive disclosure for skills and memory

Mirror Claude Code’s skill behavior with three levels:[^5]

- **Metadata layer:** maintain a registry of skills (`name`, `description`, tags, allowed tools) that is always known to the orchestrator but *not* necessarily stuffed into the LLM system prompt. Expose this registry as a separate tool the model can query when it needs capabilities.  
- **Instruction layer:** when a skill is chosen (by the user or model), load its full `SKILL.md` (or equivalent) and append it to the context strip for that turn, possibly in a dedicated `system` or `assistant`-role message.  
- **Resource layer:** treat large reference files as external tools ("ReadFile", "SearchDocs") whose outputs are summarized and only selectively injected.

For memory:

- Maintain a `memory_index` document (equivalent to MEMORY.md) that is always available at startup (or quickly retrievable from a vector store).  
- Store per‑topic memory shards and full transcripts separately; expose a `RecallMemory` tool the model can call to search them when needed.[^3][^4]

In LangGraph, a `SkillManager` node can sit before the LLM call, deciding which skills/memory chunks to materialize into the prompt based on user commands, model tool calls, or static routing rules.

### 5. Subgraphs for subagents with separate context

Use LangGraph’s support for nested graphs or separate workflows to implement subagents:

- Define a generic `SubagentRunner` node that launches a *different* LangGraph compiled graph, passing in a short task description, a subset of tools, and perhaps a copy of relevant state (e.g. repo path, CLAUDE.md‑like instructions).  
- The subgraph maintains its own history DAG and compaction, independent of the main graph.  
- When it finishes, it returns a **summary artifact** (plus, optionally, patches or diffs) to the main graph.

To emulate Claude Code’s `context: fork` semantics, ensure that subagents do *not* get the main conversation strip by default; they only see the task + necessary background.[^5][^3]

If your LLM provider supports prompt caching / KV reuse, design prompts so that shared prefixes (tools, base instructions) are stable across main and subagents, enabling cache hits similar to Claude Code’s subagent design.[^4]

### 6. Tool result and file read minimization

Adopt Claude Code’s patterns around tools:[^1][^3][^4]

- Introduce a `ToolResultFilter` node that trims or summarizes large logs before they hit the LLM.  
- Maintain a per‑file cache: if a file has been read and summarized already, prefer reusing or refining that summary instead of re‑injecting the entire file.  
- For CLIs and remote APIs, represent them as tools that return concise structured results (JSON) for the model to reason over instead of pasting raw docs.

A simple heuristic: cap the total tool‑result tokens per turn and spill excess into a separate "artifact" store, referencing it in the prompt by ID and asking the model to explicitly request more detail when necessary.

### 7. Model‑aware budgeting and explicit thresholds

Inspired by Claude’s context awareness and the unofficial "40–50%" quality threshold:[^11][^10][^7]

- Track estimated usage and keep **soft thresholds** (e.g. 40% → suggest compaction or new session; 70% → auto‑compact; 90% → refuse to proceed without clearing).  
- Surface these thresholds to the LLM via a synthetic `system_warning` message so the model can adapt verbosity.  
- Provide user‑level commands (`/context`, `/clear`, `/btw`) for manual control, implemented as special LangGraph entry points:  
  - `/clear` resets the context buffer but keeps durable history.  
  - `/btw` runs a one‑off graph that does *not* write messages into history or affect the main leaf pointer.

### 8. Explicit history filtering layer

Recreate the `db8` idea as a clean abstraction rather than a hard‑coded filter:[^6]

- Add a `HistoryFilter` component responsible for deciding which events/attachments are persisted to history and which are ephemeral.  
- Examples of ephemeral items: transient tool invocations that carry no semantic value, large binary attachments that can be re‑derived, or redundant logs.  
- Make the filter policy configurable per deployment (e.g. different behavior for internal vs external users), but ensure that any decisions that affect tool re‑introduction are understood (the `deferred_tools_delta` bug is essentially a misconfigured filter).

In LangGraph, this is simply a node between "raw events" and the history store that drops or rewrites entries according to policy.

## Takeaways for reproducing Claude Code–style context management

From both the official docs and leak‑derived analyses, the key principles are:[^1][^3][^4]

- Treat context as **multi‑layered state**, not just a chat log.  
- Store full history as a **DAG**, but project it into the LLM window via compaction and summarization.  
- Rely on **progressive disclosure** (skills, memory, tools) so rarely used knowledge does not sit in context.  
- Offload heavy exploration to **subagents with separate context windows**.  
- Aggressively **trim/compact tool outputs and logs** before sacrificing user instructions and source code.  
- Use **token budgets and thresholds** to drive automated compaction and user feedback.  
- Keep a well‑defined **filtering layer** between live turns and persisted history (db8‑style).

Implementing these ideas directly in LangGraph yields a robust, Claude Code–like harness: the graph is responsible for assembling the right slice of a rich, persistent state into each LLM call, continuously fighting context rot while preserving the reasoning backbone of the session.

---

## References

1. [How Claude Code works - Claude Code Docs](https://code.claude.com/docs/en/how-claude-code-works) - Claude Code serves as the agentic harness around Claude: it provides the tools, context management, ...

2. [Messages as Commits: Claude Code's Git-Like DAG of Conversations](https://piebald.ai/blog/messages-as-commits-claude-codes-git-like-dag-of-conversations) - Conversations and messages create one JSON object per entry. Claude Code stores each message as a JS...

3. [Best Practices for Claude Code - Claude Code Docs](https://code.claude.com/docs/en/best-practices) - Tips and patterns for getting the most out of Claude Code, from configuring your environment to scal...

4. [[AINews] The Claude Code Source Leak - Latent.Space](https://www.latent.space/p/ainews-the-claude-code-source-leak) - Macaulay_Codin highlights a significant technical issue with the leaked Claude Code, specifically th...

5. [Agent Skills - Claude API Docs](https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview) - Unlike prompts (conversation-level instructions for one-off tasks), Skills load on-demand ... Claude...

6. [Thanks to the leaked source code for Claude Code, I used Codex to ...](https://www.reddit.com/r/ClaudeAI/comments/1s8zxt4/thanks_to_the_leaked_source_code_for_claude_code/) - What's actually happening Claude Code has a function called db8 that filters what gets saved to your...

7. [Context windows - Claude API Docs](https://platform.claude.com/docs/en/build-with-claude/context-windows) - Claude API Documentation

8. [Understanding Claude Code's context with the /context command](https://www.linkedin.com/posts/kylelawrencejensen_the-context-command-will-show-you-how-much-activity-7392655875334709248-Vxxv) - The /context command will show you how much of Claude Code's context is used. What are you seeing he...

9. [include-history flag to output historical messages when resuming ...](https://github.com/anthropics/claude-code/issues/5135) - Problem When resuming a session with claude --resume <session-id>, the CLI creates a new JSONL file ...

10. [VS Code extension: Option to always show context percentage](https://github.com/anthropics/claude-code/issues/21781) - The VS Code extension's graphical panel only shows the context indicator at 80% usage. However, comm...

11. [[FEATURE] VSCode Extension: Display context usage percentage ...](https://github.com/anthropics/claude-code/issues/18456) - The CLI version of Claude Code supports custom status lines that can display context usage percentag...

12. [Here is Claude Code's `/compact` Prompt : r/ClaudeAI - Reddit](https://www.reddit.com/r/ClaudeAI/comments/1jr52qj/here_is_claude_codes_compact_prompt/) - Here is Claude Code's `/compact` Prompt ... This prompt is great to use for summarizing conversation...

13. [How to Use /compact Command in Claude Code for Task Switching](https://www.linkedin.com/posts/kylemickey_how-to-switch-between-tasks-in-claude-code-activity-7392963357160501248-6Ngk) - How to Switch Between Tasks in Claude Code Without Cluttered Context Claude Code has a /compact comm...

14. [Claude Code Skills: How AI Loads Knowledge on Demand - LinkedIn](https://www.linkedin.com/pulse/claude-code-skills-how-ai-loads-knowledge-demand-sergey-smirnov-idygc) - ... Claude Code uses a monolithic CLAUDE ... The Solution: Skills Load on Demand. Skills change the ...

15. [Managing Claude Code's Context: a practical handbook - CometAPI](https://www.cometapi.com/managing-claude-codes-context/) - Anthropic’s Claude Code and the broader Claude family now give developers unprecedented control over...

